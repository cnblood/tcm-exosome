#!/bin/bash
set -e

echo "🚀 TCM-Exosome Platform Starting..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Init database
echo "📦 Initializing database..."
python src/database/init_db.py

# Start crawler daemon in background
echo "🕷️  Starting crawler daemon (every 6h)..."
python run_crawlers.py --daemon --interval 6 > /app/logs/crawler.log 2>&1 &
CRAWLER_PID=$!
echo "   Crawler PID: $CRAWLER_PID"

# Run first crawl immediately in background
echo "🔍 Running initial crawl..."
python run_crawlers.py --once > /app/logs/first_crawl.log 2>&1 &

# Start Streamlit Dashboard
echo "🌐 Starting Dashboard on :8501 ..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

exec streamlit run src/dashboard/app.py \
    --server.port=8501 \
    --server.address=0.0.0.0 \
    --server.headless=true \
    --browser.gatherUsageStats=false
