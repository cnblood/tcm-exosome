#!/usr/bin/env python3
"""
TCM-Exosome 爬虫调度器 v2.0
用法: python run_crawlers.py [--once | --daemon | --genomics-only]
"""
import sys
import os
import time
import argparse
import logging

sys.path.insert(0, "/app")

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.database.init_db import init_db
from src.crawler.pubmed_crawler import run as run_pubmed
from src.crawler.europepmc_crawler import run as run_europepmc
from src.crawler.biorxiv_crawler import run as run_biorxiv
from src.crawler.clinicaltrials_crawler import run as run_clinicaltrials

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("/app/logs/crawler.log"),
        logging.StreamHandler()
    ]
)

def run_all():
    logging.info("=" * 50)
    logging.info("🚀 Starting all crawlers...")
    logging.info("=" * 50)

    results = {}
    crawlers = [
        ("PubMed", run_pubmed),
        ("EuropePMC", run_europepmc),
        ("bioRxiv/medRxiv", run_biorxiv),
        ("ClinicalTrials", run_clinicaltrials),
    ]

    for name, fn in crawlers:
        try:
            logging.info(f"\n{'─'*40}")
            logging.info(f"Running: {name}")
            count = fn()
            results[name] = count
        except Exception as e:
            logging.error(f"❌ {name} failed: {e}")
            results[name] = 0

    logging.info("\n" + "=" * 50)
    logging.info("📊 Crawl Summary:")
    total = 0
    for name, count in results.items():
        logging.info(f"  {name}: +{count} new records")
        total += count
    logging.info(f"  TOTAL NEW: {total}")
    logging.info("=" * 50)
    return total

def daemon_mode(interval_hours=6):
    logging.info(f"🔄 Daemon mode: running every {interval_hours} hours")
    while True:
        run_all()
        logging.info(f"😴 Sleeping {interval_hours}h until next run...")
        time.sleep(interval_hours * 3600)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--once", action="store_true", help="Run once and exit")
    parser.add_argument("--daemon", action="store_true", help="Run as daemon")
    parser.add_argument("--interval", type=int, default=6, help="Hours between runs (daemon mode)")
    args = parser.parse_args()

    # Init DB first
    os.makedirs("/app/logs", exist_ok=True)
    os.makedirs("/app/data", exist_ok=True)
    init_db()

    if args.daemon:
        daemon_mode(args.interval)
    else:
        run_all()
