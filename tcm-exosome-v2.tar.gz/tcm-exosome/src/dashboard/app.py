import streamlit as st
import sqlite3
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import os, sys
sys.path.insert(0, "/app")
from datetime import datetime

st.set_page_config(
    page_title="TCM-Exosome 智能分析平台",
    page_icon="🧬",
    layout="wide",
    initial_sidebar_state="expanded"
)

DB_PATH = os.environ.get("DB_PATH", "/app/data/tcm_exosome.db")

# ── Styles ──────────────────────────────────────────────────────────────────
st.markdown("""
<style>
.metric-card {
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
    border: 1px solid #0f3460;
    border-radius: 12px;
    padding: 20px;
    text-align: center;
    color: white;
}
.metric-value { font-size: 2.5rem; font-weight: bold; color: #e94560; }
.metric-label { font-size: 0.9rem; color: #a8b2d8; margin-top: 5px; }
.section-header {
    background: linear-gradient(90deg, #0f3460, #1a1a2e);
    color: white; padding: 10px 20px;
    border-radius: 8px; margin: 20px 0 10px 0;
    font-size: 1.2rem; font-weight: bold;
}
</style>
""", unsafe_allow_html=True)

# ── DB helpers ───────────────────────────────────────────────────────────────
@st.cache_resource
def get_conn():
    if not os.path.exists(DB_PATH):
        return None
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def query_df(sql, params=()):
    conn = get_conn()
    if conn is None:
        return pd.DataFrame()
    try:
        return pd.read_sql_query(sql, conn, params=params)
    except:
        return pd.DataFrame()

def scalar(sql, params=()):
    conn = get_conn()
    if conn is None:
        return 0
    try:
        c = conn.cursor()
        c.execute(sql, params)
        row = c.fetchone()
        return row[0] if row else 0
    except:
        return 0

# ── Sidebar ──────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 🧬 TCM-Exosome 平台")
    st.markdown("---")
    page = st.radio("📌 导航", [
        "📊 数据总览",
        "📚 文献库",
        "🏥 临床试验",
        "🔗 知识图谱",
        "📈 爬虫状态",
    ])
    st.markdown("---")
    st.markdown(f"**更新时间**\n{datetime.now().strftime('%Y-%m-%d %H:%M')}")

# ── Page: 数据总览 ───────────────────────────────────────────────────────────
if page == "📊 数据总览":
    st.markdown("# 🧬 TCM-Exosome 智能分析平台")
    st.markdown("*Traditional Chinese Medicine × Exosome Research Intelligence*")

    # Metrics row
    papers  = scalar("SELECT COUNT(*) FROM research_papers")
    trials  = scalar("SELECT COUNT(*) FROM clinical_trials")
    relations = scalar("SELECT COUNT(*) FROM herb_target_relations")
    exo_rel = scalar("SELECT COUNT(*) FROM tcm_exosome_relations")

    c1, c2, c3, c4 = st.columns(4)
    for col, val, label, icon in [
        (c1, papers,    "研究文献", "📚"),
        (c2, trials,    "临床试验", "🏥"),
        (c3, relations, "中药-靶点关系", "🔗"),
        (c4, exo_rel,   "外泌体关系", "🧬"),
    ]:
        col.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">{icon} {val:,}</div>
            <div class="metric-label">{label}</div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # Charts row
    col_l, col_r = st.columns(2)

    with col_l:
        st.markdown('<div class="section-header">📚 文献来源分布</div>', unsafe_allow_html=True)
        df_src = query_df("SELECT source, COUNT(*) as count FROM research_papers GROUP BY source ORDER BY count DESC")
        if not df_src.empty:
            fig = px.pie(df_src, names="source", values="count",
                         color_discrete_sequence=px.colors.sequential.Plasma_r,
                         hole=0.4)
            fig.update_layout(paper_bgcolor="#0d1117", plot_bgcolor="#0d1117",
                              font_color="white", margin=dict(t=20,b=20))
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("暂无数据，请先运行爬虫")

    with col_r:
        st.markdown('<div class="section-header">📅 文献年度趋势</div>', unsafe_allow_html=True)
        df_year = query_df("""
            SELECT substr(pub_date,1,4) as year, COUNT(*) as count
            FROM research_papers
            WHERE pub_date != '' AND pub_date IS NOT NULL
            GROUP BY year ORDER BY year DESC LIMIT 15
        """)
        if not df_year.empty:
            df_year = df_year[df_year["year"].str.match(r'^\d{4}$', na=False)]
            df_year = df_year.sort_values("year")
            fig2 = px.bar(df_year, x="year", y="count",
                          color="count", color_continuous_scale="Viridis")
            fig2.update_layout(paper_bgcolor="#0d1117", plot_bgcolor="#0d1117",
                               font_color="white", margin=dict(t=20,b=20))
            st.plotly_chart(fig2, use_container_width=True)
        else:
            st.info("暂无数据，请先运行爬虫")

    # Recent papers
    st.markdown('<div class="section-header">🆕 最新收录文献</div>', unsafe_allow_html=True)
    df_recent = query_df("""
        SELECT title, authors, journal, pub_date, source
        FROM research_papers ORDER BY created_at DESC LIMIT 10
    """)
    if not df_recent.empty:
        st.dataframe(df_recent, use_container_width=True, hide_index=True)
    else:
        st.info("暂无文献，请先运行爬虫")

# ── Page: 文献库 ─────────────────────────────────────────────────────────────
elif page == "📚 文献库":
    st.markdown("# 📚 文献库")

    col1, col2, col3 = st.columns([3, 1, 1])
    with col1:
        search = st.text_input("🔍 搜索标题/摘要", placeholder="输入关键词...")
    with col2:
        sources = query_df("SELECT DISTINCT source FROM research_papers ORDER BY source")
        src_list = ["全部"] + sources["source"].tolist() if not sources.empty else ["全部"]
        sel_src = st.selectbox("来源", src_list)
    with col3:
        limit = st.selectbox("每页显示", [25, 50, 100, 200])

    sql = "SELECT title, authors, journal, pub_date, source, url FROM research_papers WHERE 1=1"
    params = []
    if search:
        sql += " AND (title LIKE ? OR abstract LIKE ?)"
        params += [f"%{search}%", f"%{search}%"]
    if sel_src != "全部":
        sql += " AND source = ?"
        params.append(sel_src)
    sql += f" ORDER BY created_at DESC LIMIT {limit}"

    df = query_df(sql, params)
    total = scalar("SELECT COUNT(*) FROM research_papers")
    st.markdown(f"**共 {total:,} 篇文献，当前显示 {len(df)} 篇**")
    if not df.empty:
        st.dataframe(df, use_container_width=True, hide_index=True,
                     column_config={"url": st.column_config.LinkColumn("链接")})
    else:
        st.info("暂无文献")

# ── Page: 临床试验 ───────────────────────────────────────────────────────────
elif page == "🏥 临床试验":
    st.markdown("# 🏥 临床试验")

    df = query_df("""
        SELECT nct_id, title, status, phase, condition, intervention,
               sponsor, start_date, enrollment, url
        FROM clinical_trials ORDER BY start_date DESC
    """)

    if not df.empty:
        total = len(df)
        active = len(df[df["status"].str.contains("Recruiting|Active", na=False)])
        col1, col2 = st.columns(2)
        col1.metric("总临床试验", total)
        col2.metric("招募中", active)

        # Status distribution
        df_status = df.groupby("status").size().reset_index(name="count")
        fig = px.bar(df_status, x="status", y="count",
                     color="count", color_continuous_scale="Blues",
                     title="试验状态分布")
        fig.update_layout(paper_bgcolor="#0d1117", plot_bgcolor="#0d1117",
                          font_color="white")
        st.plotly_chart(fig, use_container_width=True)

        st.dataframe(df, use_container_width=True, hide_index=True,
                     column_config={"url": st.column_config.LinkColumn("详情")})
    else:
        st.info("暂无临床试验数据，请先运行爬虫")

# ── Page: 知识图谱 ───────────────────────────────────────────────────────────
elif page == "🔗 知识图谱":
    st.markdown("# 🔗 中药-外泌体知识图谱")

    df_rel = query_df("""
        SELECT herb_name, target_gene, relation_type, confidence
        FROM herb_target_relations
        ORDER BY confidence DESC LIMIT 200
    """)

    if not df_rel.empty:
        # Build network nodes/edges
        herbs = df_rel["herb_name"].unique()
        targets = df_rel["target_gene"].unique()

        node_x, node_y, node_text, node_color = [], [], [], []
        import math
        # herbs on left
        for i, h in enumerate(herbs[:30]):
            angle = 2 * math.pi * i / min(len(herbs), 30)
            node_x.append(math.cos(angle) * 2)
            node_y.append(math.sin(angle) * 2)
            node_text.append(h)
            node_color.append("#e94560")
        # targets on right
        for i, t in enumerate(targets[:30]):
            angle = 2 * math.pi * i / min(len(targets), 30)
            node_x.append(math.cos(angle) * 4)
            node_y.append(math.sin(angle) * 4)
            node_text.append(t)
            node_color.append("#0f3460")

        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=node_x, y=node_y, mode="markers+text",
            text=node_text, textposition="top center",
            marker=dict(size=12, color=node_color),
            hoverinfo="text"
        ))
        fig.update_layout(
            title="中药-靶点关系网络（前30×30）",
            paper_bgcolor="#0d1117", plot_bgcolor="#0d1117",
            font_color="white", showlegend=False,
            height=500
        )
        st.plotly_chart(fig, use_container_width=True)
        st.dataframe(df_rel, use_container_width=True, hide_index=True)
    else:
        st.info("暂无关系数据，爬虫运行后会自动提取")

# ── Page: 爬虫状态 ───────────────────────────────────────────────────────────
elif page == "📈 爬虫状态":
    st.markdown("# 📈 爬虫运行状态")

    df_log = query_df("""
        SELECT source, status, records_found, records_added,
               error_msg, created_at
        FROM crawler_logs ORDER BY created_at DESC LIMIT 100
    """)

    if not df_log.empty:
        # Summary cards
        sources_summary = query_df("""
            SELECT source, SUM(records_added) as total_added,
                   COUNT(*) as runs, MAX(created_at) as last_run
            FROM crawler_logs GROUP BY source
        """)
        st.dataframe(sources_summary, use_container_width=True, hide_index=True)

        st.markdown("### 详细日志")
        st.dataframe(df_log, use_container_width=True, hide_index=True)
    else:
        st.info("尚无爬虫日志。启动爬虫后日志会在此显示。")

    st.markdown("---")
    st.markdown("### 🔧 数据库状态")
    tables = ["research_papers", "clinical_trials", "herb_target_relations",
              "tcm_exosome_relations", "crawler_logs"]
    for t in tables:
        n = scalar(f"SELECT COUNT(*) FROM {t}")
        st.markdown(f"- **{t}**: {n:,} 条记录")
