"""
基因组学分析Dashboard页面
独立模块，可集成到主app.py
"""
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import json
import os
import sqlite3

DB_PATH = os.environ.get("DB_PATH", "/app/data/tcm_exosome.db")

def get_conn():
    if not os.path.exists(DB_PATH):
        return None
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def qdf(sql, params=()):
    conn = get_conn()
    if not conn:
        return pd.DataFrame()
    try:
        return pd.read_sql_query(sql, conn, params=params)
    except:
        return pd.DataFrame()

def scalar(sql, params=()):
    conn = get_conn()
    if not conn: return 0
    try:
        c = conn.cursor(); c.execute(sql, params)
        r = c.fetchone(); return r[0] if r else 0
    except: return 0

def render_gene_dashboard():
    st.markdown("# 🧬 基因组学分析中心")

    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "📊 基因总览", "🌿 中药-基因网络",
        "🔬 miRNA分析", "🔗 通路富集",
        "🏥 疾病基因图谱"
    ])

    # ── Tab1: 基因总览 ──────────────────────────────────────
    with tab1:
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("🧬 基因总数", scalar("SELECT COUNT(*) FROM genes"))
        col2.metric("🔬 miRNA数", scalar("SELECT COUNT(*) FROM mirna"))
        col3.metric("💊 中药-基因关系", scalar("SELECT COUNT(*) FROM herb_gene_relations"))
        col4.metric("📦 外泌体Cargo", scalar("SELECT COUNT(*) FROM exosome_cargo"))

        st.markdown("---")
        col_l, col_r = st.columns(2)

        with col_l:
            st.markdown("### 中药靶点基因分布")
            df = qdf("""
                SELECT herb_name_cn as 中药, COUNT(DISTINCT gene_symbol) as 靶点数
                FROM herb_gene_relations
                GROUP BY herb_name ORDER BY 靶点数 DESC
            """)
            if not df.empty:
                fig = px.bar(df, x="中药", y="靶点数",
                            color="靶点数", color_continuous_scale="Viridis",
                            title="各中药靶点基因数量")
                fig.update_layout(paper_bgcolor="#0d1117", plot_bgcolor="#0d1117",
                                  font_color="white")
                st.plotly_chart(fig, use_container_width=True)

        with col_r:
            st.markdown("### 互作类型分布")
            df2 = qdf("""
                SELECT interaction_type as 互作类型, COUNT(*) as 数量
                FROM herb_gene_relations GROUP BY interaction_type
            """)
            if not df2.empty:
                fig2 = px.pie(df2, names="互作类型", values="数量",
                             color_discrete_sequence=px.colors.qualitative.Set3,
                             hole=0.4)
                fig2.update_layout(paper_bgcolor="#0d1117", font_color="white")
                st.plotly_chart(fig2, use_container_width=True)

        st.markdown("### 📋 基因详情")
        df_genes = qdf("SELECT gene_symbol, gene_name, chromosome, description FROM genes ORDER BY gene_symbol")
        if not df_genes.empty:
            st.dataframe(df_genes, use_container_width=True, hide_index=True)
        else:
            st.info("请先运行基因爬虫")

    # ── Tab2: 中药-基因网络 ──────────────────────────────────
    with tab2:
        st.markdown("### 🌿 中药-基因-外泌体 三层网络")

        herb_filter = st.selectbox("选择中药",
            ["全部", "Astragalus(黄芪)", "Curcumin(姜黄素)",
             "Berberine(小檗碱)", "Ginseng(人参)", "Ginger(生姜)", "Resveratrol(白藜芦醇)"])

        sql = "SELECT herb_name, herb_name_cn, active_compound, gene_symbol, interaction_type, mechanism, confidence_score FROM herb_gene_relations"
        if herb_filter != "全部":
            herb_en = herb_filter.split("(")[0]
            df_hg = qdf(sql + f" WHERE herb_name='{herb_en}' ORDER BY confidence_score DESC")
        else:
            df_hg = qdf(sql + " ORDER BY confidence_score DESC")

        if not df_hg.empty:
            # 网络图
            herbs = df_hg["herb_name_cn"].unique()
            genes = df_hg["gene_symbol"].unique()

            import math
            node_x, node_y, node_text, node_color, node_size = [], [], [], [], []

            # 中药节点（左侧圆形排列）
            for i, h in enumerate(herbs):
                angle = 2 * math.pi * i / len(herbs)
                node_x.append(math.cos(angle) * 3)
                node_y.append(math.sin(angle) * 3)
                node_text.append(h)
                node_color.append("#2ecc71")
                node_size.append(20)

            # 基因节点（右侧圆形排列）
            for i, g in enumerate(genes[:30]):
                angle = 2 * math.pi * i / min(len(genes), 30)
                node_x.append(math.cos(angle) * 6)
                node_y.append(math.sin(angle) * 6)
                node_text.append(g)
                node_color.append("#e74c3c")
                node_size.append(12)

            # 边
            edge_x, edge_y = [], []
            herb_pos = {h: (node_x[i], node_y[i]) for i, h in enumerate(herbs)}
            gene_list = list(genes[:30])
            gene_pos = {g: (node_x[len(herbs)+i], node_y[len(herbs)+i]) for i, g in enumerate(gene_list)}

            for _, row in df_hg.iterrows():
                hcn = row["herb_name_cn"]
                gs = row["gene_symbol"]
                if hcn in herb_pos and gs in gene_pos:
                    hx, hy = herb_pos[hcn]
                    gx, gy = gene_pos[gs]
                    edge_x += [hx, gx, None]
                    edge_y += [hy, gy, None]

            fig = go.Figure()
            fig.add_trace(go.Scatter(x=edge_x, y=edge_y, mode="lines",
                line=dict(color="#555", width=1), hoverinfo="none"))
            fig.add_trace(go.Scatter(x=node_x, y=node_y,
                mode="markers+text", text=node_text,
                textposition="top center",
                marker=dict(size=node_size, color=node_color,
                           line=dict(width=1, color="white")),
                hoverinfo="text"))
            fig.update_layout(
                title="中药-基因关系网络图（绿色=中药，红色=基因）",
                paper_bgcolor="#0d1117", plot_bgcolor="#0d1117",
                font_color="white", showlegend=False, height=550,
                xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
                yaxis=dict(showgrid=False, zeroline=False, showticklabels=False)
            )
            st.plotly_chart(fig, use_container_width=True)

            # 数据表
            st.markdown("### 📊 关系详情表")
            st.dataframe(df_hg, use_container_width=True, hide_index=True)
        else:
            st.info("暂无数据，请先运行herb_gene_crawler")

    # ── Tab3: miRNA分析 ──────────────────────────────────────
    with tab3:
        st.markdown("### 🔬 外泌体miRNA与中药协同分析")
        col1, col2 = st.columns(2)

        with col1:
            st.markdown("#### miRNA-中药关联")
            df_mir = qdf("""
                SELECT mirna_id, source_organism as 中药来源,
                       target_genes as 靶基因, function_note as 功能
                FROM mirna WHERE is_exosome_cargo=1
            """)
            if not df_mir.empty:
                st.dataframe(df_mir, use_container_width=True, hide_index=True)

        with col2:
            st.markdown("#### 外泌体Cargo组成")
            df_cargo = qdf("""
                SELECT cargo_type as 类型, COUNT(*) as 数量
                FROM exosome_cargo GROUP BY cargo_type
            """)
            if not df_cargo.empty:
                fig = px.pie(df_cargo, names="类型", values="数量",
                            title="外泌体载货类型分布",
                            color_discrete_sequence=px.colors.sequential.Plasma)
                fig.update_layout(paper_bgcolor="#0d1117", font_color="white")
                st.plotly_chart(fig, use_container_width=True)

        st.markdown("#### 📦 外泌体Cargo详细数据")
        df_cargo_full = qdf("""
            SELECT cargo_type as 类型, cargo_name as 名称, tcm_herb as 相关中药,
                   target_gene as 靶基因, target_pathway as 通路, biological_effect as 生物效应
            FROM exosome_cargo ORDER BY cargo_type
        """)
        if not df_cargo_full.empty:
            st.dataframe(df_cargo_full, use_container_width=True, hide_index=True)

    # ── Tab4: 通路富集 ──────────────────────────────────────
    with tab4:
        st.markdown("### 🔗 KEGG通路富集分析")

        df_path = qdf("""
            SELECT herb_name as 中药, pathway_name as 通路, gene_count as 基因数,
                   enrichment_score as 富集分数, p_value as P值,
                   gene_list as 基因列表
            FROM pathway_enrichment
            ORDER BY enrichment_score DESC
        """)

        if not df_path.empty:
            # 热图
            pivot = df_path.pivot_table(
                index="通路", columns="中药", values="富集分数", aggfunc="mean"
            ).fillna(0)

            fig = px.imshow(pivot,
                           color_continuous_scale="YlOrRd",
                           title="中药-通路富集热图",
                           aspect="auto")
            fig.update_layout(paper_bgcolor="#0d1117", font_color="white", height=450)
            st.plotly_chart(fig, use_container_width=True)

            # 气泡图
            st.markdown("#### 富集气泡图")
            fig2 = px.scatter(df_path,
                x="中药", y="通路",
                size="富集分数", color="P值",
                color_continuous_scale="RdYlGn_r",
                title="通路富集气泡图（气泡越大=富集越显著）",
                size_max=30)
            fig2.update_layout(paper_bgcolor="#0d1117", plot_bgcolor="#0d1117",
                              font_color="white", height=500)
            st.plotly_chart(fig2, use_container_width=True)

            st.dataframe(df_path.drop(columns=["基因列表"]), use_container_width=True, hide_index=True)
        else:
            st.info("暂无通路富集数据，请先运行pathway_crawler")

    # ── Tab5: 疾病基因图谱 ──────────────────────────────────
    with tab5:
        st.markdown("### 🏥 疾病-基因-中药 三维网络")

        disease_filter = st.selectbox("选择疾病",
            ["全部", "Autism Spectrum Disorder",
             "Colorectal Cancer", "Breast Cancer",
             "Lung Cancer", "Inflammatory Bowel Disease"])

        sql = """SELECT disease_name as 疾病, gene_symbol as 基因,
                        association_type as 关联类型, score as 置信度,
                        tcm_herb as 相关中药, evidence_source as 证据来源
                 FROM disease_gene_network"""
        if disease_filter != "全部":
            df_dis = qdf(sql + f" WHERE disease_name='{disease_filter}' ORDER BY score DESC")
        else:
            df_dis = qdf(sql + " ORDER BY score DESC")

        if not df_dis.empty:
            col1, col2 = st.columns(2)
            with col1:
                st.metric("相关基因数", len(df_dis["基因"].unique()))
            with col2:
                st.metric("有中药干预", len(df_dis[df_dis["相关中药"].notna() & (df_dis["相关中药"]!="")]))

            # 疾病-基因置信度条形图
            fig = px.bar(df_dis.head(20),
                        x="置信度", y="基因",
                        orientation='h',
                        color="疾病",
                        title="疾病相关基因置信度排名",
                        color_discrete_sequence=px.colors.qualitative.Safe)
            fig.update_layout(paper_bgcolor="#0d1117", plot_bgcolor="#0d1117",
                             font_color="white", height=400)
            st.plotly_chart(fig, use_container_width=True)

            st.dataframe(df_dis, use_container_width=True, hide_index=True)
        else:
            st.info("暂无疾病-基因数据，请先运行herb_gene_crawler")

if __name__ == "__main__":
    render_gene_dashboard()
