import requests
import time
import sys, os
sys.path.append(os.path.join(os.path.dirname(__file__), "../.."))
from src.database.init_db import get_connection

BASE_URL = "https://www.ebi.ac.uk/europepmc/webservices/rest/search"

QUERIES = [
    "exosome traditional chinese medicine",
    "exosome herbal medicine",
    "plant exosome therapy",
    "exosome acupuncture moxibustion",
    "extracellular vesicles TCM",
    "exosome ginger curcumin",
    "exosome astragalus cancer",
    "exosome berberine inflammation",
]

def search_europepmc(query, page_size=50):
    params = {
        "query": query,
        "format": "json",
        "pageSize": page_size,
        "resultType": "core",
        "sort": "CITED desc"
    }
    try:
        r = requests.get(BASE_URL, params=params, timeout=20)
        data = r.json()
        return data.get("resultList", {}).get("result", [])
    except Exception as e:
        print(f"  Error: {e}")
        return []

def save_papers(results, query):
    conn = get_connection()
    c = conn.cursor()
    added = 0
    for item in results:
        try:
            authors = item.get("authorString", "")
            doi = item.get("doi", None)
            pmid = item.get("pmid", None)
            title = item.get("title", "")
            if not title:
                continue
            c.execute("""
                INSERT OR IGNORE INTO research_papers
                (title, authors, abstract, journal, pub_date, doi, pmid, source, keywords, url)
                VALUES (?,?,?,?,?,?,?,?,?,?)
            """, (
                title, authors,
                item.get("abstractText", ""),
                item.get("journalTitle", ""),
                str(item.get("pubYear", "")),
                doi, pmid, "EuropePMC",
                query,
                f"https://europepmc.org/article/{item.get('source','MED')}/{item.get('id','')}"
            ))
            if c.rowcount > 0:
                added += 1
        except Exception as e:
            print(f"  DB error: {e}")
    conn.commit()
    c.execute("""INSERT INTO crawler_logs (source, status, records_found, records_added)
                 VALUES (?,?,?,?)""", ("EuropePMC", "success", len(results), added))
    conn.commit()
    conn.close()
    return added

def run():
    print("🔍 Starting EuropePMC crawler...")
    total = 0
    for q in QUERIES:
        print(f"  Query: {q}")
        results = search_europepmc(q)
        print(f"    Found {len(results)}")
        added = save_papers(results, q)
        total += added
        print(f"    Added {added}")
        time.sleep(1)
    print(f"✅ EuropePMC done. Total new: {total}")
    return total

if __name__ == "__main__":
    run()
