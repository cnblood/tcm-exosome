import requests
import time
import sys, os
sys.path.append(os.path.join(os.path.dirname(__file__), "../.."))
from src.database.init_db import get_connection

# bioRxiv/medRxiv API
BASE_URL = "https://api.biorxiv.org/details/{server}/{interval}/0/json"

SEARCH_TERMS = [
    "exosome", "extracellular vesicle", "chinese medicine",
    "traditional medicine", "herbal", "TCM"
]

def fetch_recent(server="biorxiv", interval="2024-01-01/2025-12-31", cursor=0):
    url = f"https://api.biorxiv.org/details/{server}/{interval}/{cursor}/json"
    try:
        r = requests.get(url, timeout=20)
        data = r.json()
        return data.get("collection", []), data.get("messages", [{}])[0].get("total", 0)
    except Exception as e:
        print(f"  Error: {e}")
        return [], 0

def is_relevant(paper):
    text = (paper.get("title","") + " " + paper.get("abstract","")).lower()
    tcm_terms = ["exosome","extracellular vesicle","traditional chinese","herbal","tcm","acupuncture","herb"]
    return any(t in text for t in tcm_terms)

def save_papers(papers, source):
    conn = get_connection()
    c = conn.cursor()
    added = 0
    for p in papers:
        if not is_relevant(p):
            continue
        try:
            doi = p.get("doi","")
            c.execute("""
                INSERT OR IGNORE INTO research_papers
                (title, authors, abstract, journal, pub_date, doi, source, keywords, url)
                VALUES (?,?,?,?,?,?,?,?,?)
            """, (
                p.get("title",""),
                p.get("authors",""),
                p.get("abstract",""),
                source,
                p.get("date",""),
                doi if doi else None,
                source,
                p.get("category",""),
                f"https://doi.org/{doi}" if doi else ""
            ))
            if c.rowcount > 0:
                added += 1
        except Exception as e:
            print(f"  DB: {e}")
    conn.commit()
    c.execute("""INSERT INTO crawler_logs (source,status,records_found,records_added)
                 VALUES (?,?,?,?)""", (source,"success",len(papers),added))
    conn.commit()
    conn.close()
    return added

def run():
    print("🔍 Starting bioRxiv/medRxiv crawler...")
    total = 0
    for server in ["biorxiv", "medrxiv"]:
        print(f"  Server: {server}")
        papers, count = fetch_recent(server)
        print(f"    Fetched {len(papers)} papers")
        added = save_papers(papers, server)
        total += added
        print(f"    Relevant & added: {added}")
        time.sleep(2)
    print(f"✅ bioRxiv/medRxiv done. Total new: {total}")
    return total

if __name__ == "__main__":
    run()
