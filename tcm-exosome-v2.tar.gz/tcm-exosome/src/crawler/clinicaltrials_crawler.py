import requests
import time
import sys, os
sys.path.append(os.path.join(os.path.dirname(__file__), "../.."))
from src.database.init_db import get_connection

BASE_URL = "https://clinicaltrials.gov/api/v2/studies"

QUERIES = [
    "exosome traditional chinese medicine",
    "exosome herbal",
    "exosome acupuncture",
    "plant exosome therapy",
    "extracellular vesicle TCM",
    "exosome cancer herb",
]

def fetch_trials(query, page_size=20):
    params = {
        "query.term": query,
        "pageSize": page_size,
        "format": "json",
        "fields": "NCTId,BriefTitle,OverallStatus,Phase,Condition,InterventionName,LeadSponsorName,StartDate,PrimaryCompletionDate,EnrollmentCount"
    }
    try:
        r = requests.get(BASE_URL, params=params, timeout=20)
        data = r.json()
        return data.get("studies", [])
    except Exception as e:
        print(f"  Error: {e}")
        return []

def save_trials(studies):
    conn = get_connection()
    c = conn.cursor()
    added = 0
    for s in studies:
        proto = s.get("protocolSection", {})
        id_mod = proto.get("identificationModule", {})
        status_mod = proto.get("statusModule", {})
        design_mod = proto.get("designModule", {})
        cond_mod = proto.get("conditionsModule", {})
        interv_mod = proto.get("armsInterventionsModule", {})
        sponsor_mod = proto.get("sponsorCollaboratorsModule", {})

        nct_id = id_mod.get("nctId", "")
        if not nct_id:
            continue

        interventions = interv_mod.get("interventions", [])
        interv_names = ", ".join([i.get("name","") for i in interventions[:3]])

        try:
            c.execute("""
                INSERT OR IGNORE INTO clinical_trials
                (nct_id,title,status,phase,condition,intervention,sponsor,start_date,completion_date,enrollment,url)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)
            """, (
                nct_id,
                id_mod.get("briefTitle",""),
                status_mod.get("overallStatus",""),
                ", ".join(design_mod.get("phases",[])),
                ", ".join(cond_mod.get("conditions",[])),
                interv_names,
                sponsor_mod.get("leadSponsor",{}).get("name",""),
                status_mod.get("startDateStruct",{}).get("date",""),
                status_mod.get("primaryCompletionDateStruct",{}).get("date",""),
                design_mod.get("enrollmentInfo",{}).get("count",0),
                f"https://clinicaltrials.gov/study/{nct_id}"
            ))
            if c.rowcount > 0:
                added += 1
        except Exception as e:
            print(f"  DB: {e}")
    conn.commit()
    c.execute("""INSERT INTO crawler_logs (source,status,records_found,records_added)
                 VALUES (?,?,?,?)""", ("ClinicalTrials","success",len(studies),added))
    conn.commit()
    conn.close()
    return added

def run():
    print("🔍 Starting ClinicalTrials crawler...")
    total = 0
    for q in QUERIES:
        print(f"  Query: {q}")
        studies = fetch_trials(q)
        print(f"    Found {len(studies)}")
        added = save_trials(studies)
        total += added
        print(f"    Added {added}")
        time.sleep(1)
    print(f"✅ ClinicalTrials done. Total new: {total}")
    return total

if __name__ == "__main__":
    run()
