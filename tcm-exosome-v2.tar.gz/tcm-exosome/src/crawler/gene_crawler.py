"""
NCBI Gene & UniProt 爬虫
爬取与中药/外泌体相关的基因详细信息
"""
import requests
import time
import json
import sys, os
sys.path.append(os.path.join(os.path.dirname(__file__), "../.."))
from src.database.init_db import get_connection

# 核心关注基因列表（中药/外泌体研究高频基因）
TCM_EXOSOME_GENES = [
    # 炎症/免疫通路
    "TNF", "IL6", "IL1B", "IL10", "NFKB1", "STAT3", "TLR4",
    # 凋亡通路
    "TP53", "BCL2", "BAX", "CASP3", "CASP9",
    # 血管生成
    "VEGFA", "HIF1A", "MMP2", "MMP9",
    # PI3K/AKT/mTOR
    "PIK3CA", "AKT1", "MTOR", "PTEN",
    # MAPK通路
    "MAPK1", "MAPK3", "EGFR", "KRAS",
    # 神经相关（ASD）
    "SHANK3", "NLGN3", "NRXN1", "MECP2", "FMR1",
    # 外泌体生物发生
    "RAB27A", "RAB27B", "ALIX", "TSG101", "CD63", "CD9", "CD81",
    # 中药主要靶点
    "CYP1A2", "CYP3A4", "PTGS2", "NOS2", "HMOX1",
    # 表观遗传
    "DNMT1", "HDAC1", "SIRT1",
    # microRNA相关
    "DICER1", "DROSHA", "AGO2",
]

NCBI_ESEARCH = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
NCBI_EFETCH  = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
NCBI_ESUMMARY = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi"
UNIPROT_API  = "https://rest.uniprot.org/uniprotkb/search"

def fetch_gene_info_ncbi(gene_symbol):
    """通过NCBI Gene获取基因信息"""
    # Search
    try:
        r = requests.get(NCBI_ESEARCH, params={
            "db": "gene", "term": f"{gene_symbol}[Gene Name] AND Homo sapiens[Organism]",
            "retmax": 1, "retmode": "json"
        }, timeout=15)
        ids = r.json().get("esearchresult", {}).get("idlist", [])
        if not ids:
            return None

        gene_id = ids[0]
        time.sleep(0.4)

        # Summary
        r2 = requests.get(NCBI_ESUMMARY, params={
            "db": "gene", "id": gene_id, "retmode": "json"
        }, timeout=15)
        data = r2.json().get("result", {}).get(gene_id, {})

        return {
            "gene_symbol": gene_symbol,
            "gene_name": data.get("description", ""),
            "ncbi_gene_id": gene_id,
            "chromosome": data.get("chromosome", ""),
            "description": data.get("summary", "")[:500] if data.get("summary") else "",
            "function_summary": data.get("otheraliases", "")
        }
    except Exception as e:
        print(f"    NCBI error for {gene_symbol}: {e}")
        return None

def fetch_uniprot_id(gene_symbol):
    """从UniProt获取蛋白ID"""
    try:
        r = requests.get(UNIPROT_API, params={
            "query": f"gene_exact:{gene_symbol} AND organism_id:9606 AND reviewed:true",
            "format": "json", "size": 1,
            "fields": "accession,id,protein_name"
        }, timeout=15)
        results = r.json().get("results", [])
        if results:
            return results[0].get("primaryAccession", "")
        return ""
    except:
        return ""

def save_gene(gene_data):
    conn = get_connection()
    c = conn.cursor()
    try:
        c.execute("""
            INSERT OR REPLACE INTO genes
            (gene_symbol, gene_name, ncbi_gene_id, uniprot_id, chromosome, description, function_summary)
            VALUES (?,?,?,?,?,?,?)
        """, (
            gene_data["gene_symbol"],
            gene_data.get("gene_name",""),
            gene_data.get("ncbi_gene_id",""),
            gene_data.get("uniprot_id",""),
            gene_data.get("chromosome",""),
            gene_data.get("description",""),
            gene_data.get("function_summary","")
        ))
        conn.commit()
        return c.rowcount > 0
    except Exception as e:
        print(f"    DB error: {e}")
        return False
    finally:
        conn.close()

def run():
    print("🧬 Starting NCBI Gene crawler...")
    added = 0
    for i, gene in enumerate(TCM_EXOSOME_GENES):
        print(f"  [{i+1}/{len(TCM_EXOSOME_GENES)}] {gene}")
        info = fetch_gene_info_ncbi(gene)
        if info:
            uniprot = fetch_uniprot_id(gene)
            info["uniprot_id"] = uniprot
            if save_gene(info):
                added += 1
                print(f"    ✓ {info['gene_name'][:50]}")
        time.sleep(0.5)

    print(f"✅ Gene crawler done. Added/updated: {added}")
    return added

if __name__ == "__main__":
    run()
