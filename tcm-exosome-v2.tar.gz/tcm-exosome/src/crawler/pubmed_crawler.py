import requests
import time
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), "../.."))
from src.database.init_db import get_connection

KEYWORDS = [
    "exosome traditional chinese medicine",
    "exosome TCM herb",
    "exosome acupuncture",
    "exosome astragalus",
    "exosome berberine",
    "exosome curcumin",
    "extracellular vesicles chinese medicine",
    "exosome cancer TCM",
    "plant exosome ginger",
    "plant derived exosome",
]

PUBMED_SEARCH = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
PUBMED_FETCH  = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
PUBMED_SUMMARY = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi"

def search_pubmed(query, retmax=50):
    params = {
        "db": "pubmed", "term": query,
        "retmax": retmax, "retmode": "json",
        "sort": "relevance"
    }
    try:
        r = requests.get(PUBMED_SEARCH, params=params, timeout=15)
        data = r.json()
        return data.get("esearchresult", {}).get("idlist", [])
    except Exception as e:
        print(f"  Search error: {e}")
        return []

def fetch_summaries(pmids):
    if not pmids:
        return []
    params = {
        "db": "pubmed", "id": ",".join(pmids),
        "retmode": "json"
    }
    try:
        r = requests.get(PUBMED_SUMMARY, params=params, timeout=20)
        data = r.json()
        results = []
        uids = data.get("result", {}).get("uids", [])
        for uid in uids:
            item = data["result"].get(uid, {})
            authors = ", ".join([a.get("name","") for a in item.get("authors", [])[:5]])
            results.append({
                "title": item.get("title", ""),
                "authors": authors,
                "journal": item.get("fulljournalname", item.get("source", "")),
                "pub_date": item.get("pubdate", ""),
                "pmid": uid,
                "doi": next((i["value"] for i in item.get("articleids",[]) if i["idtype"]=="doi"), None),
                "url": f"https://pubmed.ncbi.nlm.nih.gov/{uid}/",
                "source": "PubMed",
                "abstract": "",
                "keywords": ""
            })
        return results
    except Exception as e:
        print(f"  Fetch error: {e}")
        return []

def save_papers(papers):
    conn = get_connection()
    c = conn.cursor()
    added = 0
    for p in papers:
        try:
            c.execute("""
                INSERT OR IGNORE INTO research_papers
                (title, authors, abstract, journal, pub_date, doi, pmid, source, keywords, url)
                VALUES (?,?,?,?,?,?,?,?,?,?)
            """, (p["title"], p["authors"], p["abstract"], p["journal"],
                  p["pub_date"], p["doi"], p["pmid"], p["source"], p["keywords"], p["url"]))
            if c.rowcount > 0:
                added += 1
        except Exception as e:
            print(f"  DB error: {e}")
    conn.commit()

    # log
    c.execute("""INSERT INTO crawler_logs (source, status, records_found, records_added)
                 VALUES (?,?,?,?)""", ("PubMed", "success", len(papers), added))
    conn.commit()
    conn.close()
    return added

def run():
    print("🔍 Starting PubMed crawler...")
    total_added = 0
    for kw in KEYWORDS:
        print(f"  Query: {kw}")
        pmids = search_pubmed(kw, retmax=50)
        print(f"    Found {len(pmids)} IDs")
        if pmids:
            papers = fetch_summaries(pmids)
            added = save_papers(papers)
            total_added += added
            print(f"    Added {added} new papers")
        time.sleep(0.5)  # respect rate limit
    print(f"✅ PubMed done. Total new: {total_added}")
    return total_added

if __name__ == "__main__":
    run()
