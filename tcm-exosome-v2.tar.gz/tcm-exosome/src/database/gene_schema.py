"""
基因组学数据库扩展
新增表：genes, mirna, herb_gene_relations, exosome_cargo, pathway_enrichment, disease_gene_network
"""
import sqlite3
import os

DB_PATH = os.environ.get("DB_PATH", "/app/data/tcm_exosome.db")

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def extend_gene_schema():
    conn = get_connection()
    c = conn.cursor()
    c.executescript("""
    -- 基因基本信息表
    CREATE TABLE IF NOT EXISTS genes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        gene_symbol TEXT UNIQUE,
        gene_name TEXT,
        ncbi_gene_id TEXT,
        uniprot_id TEXT,
        chromosome TEXT,
        description TEXT,
        function_summary TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- miRNA表（外泌体核心载货）
    CREATE TABLE IF NOT EXISTS mirna (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        mirna_id TEXT UNIQUE,         -- e.g. hsa-miR-21-5p
        mirna_acc TEXT,               -- miRBase accession
        sequence TEXT,
        source_organism TEXT,
        target_genes TEXT,            -- JSON list
        function_note TEXT,
        is_exosome_cargo INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- 中药-基因关系表（核心！）
    CREATE TABLE IF NOT EXISTS herb_gene_relations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        herb_name TEXT,
        herb_name_cn TEXT,
        active_compound TEXT,         -- 活性成分 e.g. berberine
        gene_symbol TEXT,
        interaction_type TEXT,        -- inhibit/activate/upregulate/downregulate
        mechanism TEXT,               -- 作用机制描述
        disease_context TEXT,
        confidence_score REAL DEFAULT 0.0,
        source_db TEXT,               -- TCMSP/HIT/literature
        pmid TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- 外泌体载货表（cargo）
    CREATE TABLE IF NOT EXISTS exosome_cargo (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        cargo_type TEXT,              -- miRNA/mRNA/protein/lncRNA
        cargo_id TEXT,
        cargo_name TEXT,
        source_cell TEXT,             -- 来源细胞/组织
        tcm_herb TEXT,                -- 相关中药
        target_gene TEXT,
        target_pathway TEXT,
        biological_effect TEXT,
        exocarta_id TEXT,
        vesiclepedia_id TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- 通路富集结果表
    CREATE TABLE IF NOT EXISTS pathway_enrichment (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        analysis_id TEXT,             -- 分析批次ID
        herb_name TEXT,
        pathway_id TEXT,              -- KEGG/GO ID
        pathway_name TEXT,
        pathway_type TEXT,            -- KEGG/GO_BP/GO_MF/GO_CC
        gene_count INTEGER,
        gene_list TEXT,               -- JSON
        p_value REAL,
        adjusted_p REAL,
        enrichment_score REAL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- 疾病-基因网络表
    CREATE TABLE IF NOT EXISTS disease_gene_network (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        disease_name TEXT,
        disease_id TEXT,              -- OMIM/MeSH ID
        gene_symbol TEXT,
        association_type TEXT,
        score REAL,
        tcm_herb TEXT,               -- 相关中药（如有）
        exosome_linked INTEGER DEFAULT 0,
        evidence_source TEXT,
        pmid TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- 网络分析节点表（用于可视化）
    CREATE TABLE IF NOT EXISTS network_nodes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        node_id TEXT UNIQUE,
        node_type TEXT,              -- herb/gene/mirna/pathway/disease
        node_label TEXT,
        node_data TEXT,              -- JSON 附加属性
        degree INTEGER DEFAULT 0,
        betweenness REAL DEFAULT 0.0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- 网络边表
    CREATE TABLE IF NOT EXISTS network_edges (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        source_id TEXT,
        target_id TEXT,
        edge_type TEXT,
        weight REAL DEFAULT 1.0,
        evidence TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE INDEX IF NOT EXISTS idx_hgr_herb ON herb_gene_relations(herb_name);
    CREATE INDEX IF NOT EXISTS idx_hgr_gene ON herb_gene_relations(gene_symbol);
    CREATE INDEX IF NOT EXISTS idx_dgn_disease ON disease_gene_network(disease_name);
    CREATE INDEX IF NOT EXISTS idx_dgn_gene ON disease_gene_network(gene_symbol);
    CREATE INDEX IF NOT EXISTS idx_ec_herb ON exosome_cargo(tcm_herb);
    CREATE INDEX IF NOT EXISTS idx_pe_herb ON pathway_enrichment(herb_name);
    """)
    conn.commit()
    conn.close()
    print("✅ Gene schema extended successfully")

if __name__ == "__main__":
    extend_gene_schema()
