import sqlite3
import os

DB_PATH = os.environ.get("DB_PATH", "/app/data/tcm_exosome.db")

def get_connection():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_connection()
    c = conn.cursor()

    c.executescript("""
    CREATE TABLE IF NOT EXISTS research_papers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        authors TEXT,
        abstract TEXT,
        journal TEXT,
        pub_date TEXT,
        doi TEXT UNIQUE,
        pmid TEXT UNIQUE,
        source TEXT,
        keywords TEXT,
        url TEXT,
        processed INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS clinical_trials (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nct_id TEXT UNIQUE,
        title TEXT,
        status TEXT,
        phase TEXT,
        condition TEXT,
        intervention TEXT,
        sponsor TEXT,
        start_date TEXT,
        completion_date TEXT,
        enrollment INTEGER,
        url TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS herb_target_relations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        herb_name TEXT,
        herb_name_cn TEXT,
        target_gene TEXT,
        target_protein TEXT,
        relation_type TEXT,
        evidence TEXT,
        confidence REAL DEFAULT 0.0,
        paper_id INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS tcm_exosome_relations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subject TEXT,
        subject_type TEXT,
        predicate TEXT,
        object TEXT,
        object_type TEXT,
        evidence TEXT,
        confidence REAL DEFAULT 0.0,
        paper_id INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS crawler_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        source TEXT,
        status TEXT,
        records_found INTEGER DEFAULT 0,
        records_added INTEGER DEFAULT 0,
        error_msg TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    conn.commit()
    conn.close()
    print(f"✅ Database initialized at {DB_PATH}")

if __name__ == "__main__":
    init_db()
