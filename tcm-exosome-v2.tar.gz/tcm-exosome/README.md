# 🧬 TCM-Exosome 智能分析平台 v3.0

## 📋 部署步骤（Windows → Docker Hub → Claw Cloud）

---

## 第一步：本地环境准备

确保已安装：
- Git: https://git-scm.com/download/win
- Docker Desktop: https://www.docker.com/products/docker-desktop/

---

## 第二步：初始化本地项目

打开 **PowerShell**，执行：

```powershell
# 进入项目目录（下载本项目后）
cd tcm-exosome

# 登录Docker Hub（替换your_username）
docker login
```

---

## 第三步：构建并推送Docker镜像

```powershell
# 替换 your_dockerhub_username 为你的Docker Hub用户名
$USERNAME = "your_dockerhub_username"

# 构建镜像
docker build -t $USERNAME/tcm-exosome:latest .

# 推送到Docker Hub
docker push $USERNAME/tcm-exosome:latest
```

⏱️ 构建约需 2-5 分钟

---

## 第四步：在Claw Cloud部署

1. 打开 https://run.claw.cloud
2. 点击 **App Launchpad** → **New Application**
3. 填写配置：

| 字段 | 值 |
|------|-----|
| Application Name | `tcm-exosome` |
| Image | Public |
| Image Name | `your_dockerhub_username/tcm-exosome:latest` |
| CPU | 0.5 |
| Memory | 512M |
| Replicas | 1 |

4. **Network** 部分：
   - 点击 "Add Port"
   - Port: `8501`
   - 开启 "Public Access"

5. 点击右上角 **Deploy Application**

6. 等待约 2 分钟，获得公网地址：
   ```
   https://tcm-exosome-xxxx.ap-southeast-1.clawcloudrun.com
   ```

---

## 第五步：验证运行

访问你的公网地址，应该看到Dashboard！

初次运行爬虫会在后台自动启动，约30分钟后数据开始填充。

---

## ⚠️ 关于数据持久化

Claw Cloud容器重启后数据会丢失（SQLite在容器内）。

**解决方案：** 在Claw Cloud申请 Object Storage 并挂载，
或使用免费的 Supabase PostgreSQL：https://supabase.com（免费500MB）

---

## 🔧 常用命令

```powershell
# 本地测试运行
docker run -p 8501:8501 your_username/tcm-exosome:latest

# 更新部署（修改代码后）
docker build -t your_username/tcm-exosome:latest .
docker push your_username/tcm-exosome:latest
# 然后在Claw Cloud点击 "Redeploy"
```

---

## 📁 项目结构

```
tcm-exosome/
├── src/
│   ├── dashboard/app.py          # Streamlit Dashboard
│   ├── crawler/
│   │   ├── pubmed_crawler.py     # PubMed爬虫
│   │   ├── europepmc_crawler.py  # EuropePMC爬虫
│   │   ├── biorxiv_crawler.py    # bioRxiv/medRxiv爬虫
│   │   └── clinicaltrials_crawler.py # 临床试验爬虫
│   └── database/init_db.py      # 数据库初始化
├── run_crawlers.py               # 爬虫调度器
├── Dockerfile
├── docker-entrypoint.sh
└── requirements.txt
```
